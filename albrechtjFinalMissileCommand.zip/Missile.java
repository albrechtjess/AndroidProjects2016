package net.albrechtjess.albrechtjessmisslecommand;

/**
 * Created by Jess on 6/5/2016.
 */
public class Missile {
}
